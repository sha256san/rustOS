uname -a
cat /etc/os-release
whoami
ls -la /var/log/
head -n 20 /var/log/syslog
systemctl status
sudo apt update
