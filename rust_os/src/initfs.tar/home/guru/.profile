# ~/.profile: executed by the command interpreter
export PATH="/bin:/usr/bin:/sbin:/usr/sbin"
alias ll='ls -lh'
alias la='ls -A'
